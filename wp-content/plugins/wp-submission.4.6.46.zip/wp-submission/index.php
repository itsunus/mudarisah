<?php /*
Plugin Name: Submission
Plugin URI: http://contactme.dcoda.co.uk/
Description: Easy way to collect user submitted content for you blog.
Author: dcoda
Author URI: 
Version: 4.5.46
License: GPLv2
*/
@require_once  dirname ( __FILE__ ) . '/library/wordpress/application.php';
@include_once (ABSPATH.'wp-admin/includes/post.php');
new wv46v_application ( __FILE__);