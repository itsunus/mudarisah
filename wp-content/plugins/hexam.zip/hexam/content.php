<?php
$word["hsubmit"]="Finishs";
$word["hscore_1"]="Your score is";
$word["hscore_2"]="points";
$word["hrec"]="Your results has been received";
$word["hbut"]="But we can not accept your result because of you did this test before";
$word["hlogin"]="You must be logged in to participate in this test";
?>
