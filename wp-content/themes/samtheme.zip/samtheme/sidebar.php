
<div class="sidebar">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebardifault') ) : ?>
    <?php endif; ?>
</div>

<!--
<div class="sidebar_outer">
    <div class="sidebar">
        <h1>Catagory</h1>
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">Home</a></li>
            <li><a href="#">Home</a></li>
            <li><a href="#">Home</a></li>
            <li><a href="#">Home</a></li>
        </ul>
    </div>
</div>

-->