tinyMCE.addI18n("en.yoppoll", {
	insert : 'Insert Yop Poll'
});