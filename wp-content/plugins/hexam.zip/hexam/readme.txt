=== HEXAM ===
Contributors: Elvin Haci
Donate link: http://webania.net/hexam#donate
Tags: test, quiz, exam, examination
Requires at least: 3
Tested up to: 3.1
Stable tag: 1.3

Provide online exams,quizzes in your wordpress web site.

== Description ==

By using HEXAM PLUGIN (online examination system) you can provide online exams,quizzes in your web site. It is very easy, you can create a lot of tests in your site and place it in
posts or pages. You can choose how many questions each quiz may contain, you can also set number of answers for each question. Users can send their results after doing test. You can also view
how many points each user has scored and you can see and post users' ranking table in wp.

== Installation ==

Simple:

1. Descompress the file
2. Upload the directory `hexam/` to the `wp-content/plugins/` directory.
3. Activate the plugin
4. Go to Settings > HEXAM SETTINGS to change your settings

== Frequently Asked Questions ==

= Can i use images in question or answer content?=
Yes of course. HTML tags are is permitted in Hexam content. For example, just type <img src="picture_name.picture_type"><br> and it is ready.

= After test made i can place this quiz to my site. But how?=
It is very easy. When you create or edit post or page, type in there(in the fields) just this: [hexam id=test_number hexam] , that's all. (test_number is number:= 1,2,3...)

== Screenshots ==
<h3>Example</h3>
`http://webania.net/wp-content/uploads/2010/11/screenshort-1.jpg`

<h3>Options</h3>
`http://webania.net/wp-content/uploads/2010/11/screenshort-2.jpg`

== Changelog ==
1.3 Some bugfixes, code optimizations

1.2.4 A little html bug has been fixed.

1.2.3 The bug about visibility of user messages(your results has been reveived, finish, scored and etc. ) has been fixed.

1.2.2 Shorttags completely removed.

== Arbitrary section ==

== A brief Markdown Example ==
