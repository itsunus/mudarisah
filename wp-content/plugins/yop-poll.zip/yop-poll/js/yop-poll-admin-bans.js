jQuery(document).ready(function(jQuery) {
		jQuery('#yop-poll-add-new-ban').click( function() {
			jQuery('#yop-poll-add-ban-div').fadeIn('medium');
		});
		jQuery('#yop-poll-add-ban-close').click( function() {
			jQuery('#yop-poll-add-ban-div').fadeOut('medium');
		});		
});		