<?php get_header();?>
<div class="warp">
	<div class="inwarp">
		<div class="content">
            <div class="content_post_area">
            	
            	<div class="post_outer">
                    <div class="post">
                        <p class="catagorys"> </p>
                        <h1 class="title"></h1>
                        <div class="date_comment">
                            <p class="coment_place"></p>
                            <h5 class="date"> </h5>                        
                         </div>

                        <div class="discription">
                        
							<h2>Error 404 - Page Not Found</h2>
                 			
                        </div>
                    </div>
                 </div>
            </div>
            <div class="sidebar_area">
				<?php get_sidebar();?>
            </div>
        </div>
	</div>
</div>
<?php get_footer();?>
