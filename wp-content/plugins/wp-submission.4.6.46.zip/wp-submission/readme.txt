=== Submission ===
Contributors: dcoda
Donate link: http://contactme.dcoda.co.uk/donate/
Stable tag: 4.5.45
Tags: contact, captcha, data collection, survey, poll, quiz
Requires at least: 3.0.0
Tested up to: 3.3.1
Easy way to collect user submitted content for you blog.
== Description ==
This plugin is only supported on PHP 5.2 or greater.

<!--description-->
Submission is an easy to use and easy to modify form for 'Blog Carnivals', 'Roundups' or what every you want to call them, basically user submitted content to posts.
Original commission and idea by chrisg.com. It has been re-written to be easy to use to none coders, it has been written to allow advanced users to tweak almost all aspects of the look and feel of the form.
<!--description-->

If you are having trouble and cannot find the answers in the <a href="http://submission.dcoda.co.uk/help/faq/">FAQ</a> you can post your support questions to the <a href = "http://wordpress.org/tags/wp-submission">WordPress Support Forum</a>

If you find Submission useful please rate it at <a href="http://wordpress.org/extend/plugins/wp-submission/">wordpress.org</a> and please consider making a <a href="http://contactme.dcoda.co.uk/donate/">donation</a> to help us set aside more hours to maintain Submission 

Submission is written by <a href='http://dcoda.co.uk'>dcoda</a>

You can check out our other plugins <a href="http://profiles.wordpress.org/users/dcoda/">here</a>

If you require a custom plugin you can contact us <a href="http://dcoda.co.uk/contact/">here</a> and maybe we could write it for you.

== Installation ==
For installation instructions and help click [here](http://submission.dcoda.co.uk/help/installation/).
== Frequently Asked Questions ==
For frequently asked questions and help click [here](http://submission.dcoda.co.uk/help/faq/).
=== Copyright ==

(c) Copyright DCoda Limited, 2007 -, All Rights Reserved.

This code is released under the GPL license version 2, available here:

[http://www.gnu.org/licenses/gpl.txt](http://www.gnu.org/licenses/gpl.txt)

There are so many possibly configurations of installation the plugin can be installed on we limit testing to a PHP 5.2+ Linux platform running the latest version of WordPress at the time of release but it is released WITHOUT ANY WARRANTY;
 without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
